// ---------------------------------
// Project _xxx_, view the README.md
// ---------------------------------

// --- NO TOQUES LOS INCLUDE ---
#include <sdcc-lib.h>
#include <stdint.h>  //uint8_t, ..
#include <stdbool.h> //bool
#include <newTypes.h> // Optional
#include <defines.h> // definiciones imprescindibles
#include <basic.h>   // controla interrupciones y V-Blank, así como carga en memoria VDP
#include <main.h>    // controla el ciclo de vida de la app, así como la definición de las funciones aquí utilizadas.
#include "const.h"   // otras definiciones y constantes para este juego concreto

// INCLUSIONES CONDICIONALES DEL TUTORIAL
#if _TUTO2_0 || _TUTO2_1
    #include <bg_template_def.h> // plantilla de definiciones
#endif
#if _TUTO2_2
    #include <ball_def.h> // plantilla de definiciones
#endif


extern uint32_t _DELTA;
extern uint8_t _MASTER;

#if _TUTO3_0 || _TUTO3_1
    // variables globales para el movimiento autoexplicativas
    uint8_t xBall = 0;
    uint8_t yBall = 0;
    uint8_t xIncr = 1;
    uint8_t yIncr = 1;
#endif

void init(void){
    #if _TUTO2_1
        __asm__("di"); //; Des-Habilitar interrupciones
        // unable display (0x8120)
        VDP_ADDRESS = 0b00100000; // 0x20; // 32
        VDP_ADDRESS = 0x81;
    #endif

    #if _TUTO2_0 || _TUTO2_1
        // FONDO
        write_palette(PALETTE_OFFSET_TILES, _bg_template_pal);
        write_vram(_bg_template_til, _bg_template_size, 0);
        write_vram_2(_bg_template_tilemap, _bg_template_tilemap_size, 0x3800);
    #endif
    #if _TUTO2_2
        // SPRITES
        write_palette(PALETTE_OFFSET_SPRITES, _pal_base);
        write_vram(_ball_til, _ball_size, _VRAM_SPRITE_PATT);
    #endif

    #if _TUTO2_1
        // enable display (0x8160)
        VDP_ADDRESS = 0b01100000; // 0x60; // 96
        VDP_ADDRESS = 0x81;
        __asm__("ei"); //; Habilitar interrupciones
    #endif
    #if _TUTO3_0 || _TUTO3_1
        // variables globales autoexplicativas
        xBall = 0;
        yBall = 0;
        xIncr = 1;
        yIncr = 1;
    #endif
}

//#include "sounds.asm"
//extern void play_sound1(void);
/*
Cuando entramos a la función:
- SP+0 y SP+1 contienen la dirección de retorno (2 bytes).
- SP+2 y SP+3 contienen el primer parámetro (destino_vram, de 16 bits).
- SP+4 contiene el segundo parámetro (dato, de 8 bits).
 */

#if _TUTO3_0 || _TUTO3_1
    /** controla el movimiento de la bolita sin salirse de los límites. Retorna "true" si se sale. */
    bool moveBall(void){
        bool result = false;
        xBall += xIncr;
        if ((xBall >= _SCREEN_WIDTH - 8) || (xBall <= 0)){
            xIncr *= -1;
            result = true;
        }
        yBall += yIncr;
        if ((yBall >= _SCREEN_HEIGHT - 8) || (yBall <= 0)){
            yIncr *= -1;
            result = true;
        }
        return result;
    }
#endif

#if _TUTO4_0
    /** crea un pequeño sonido "beep" */
    void beep(void){
        //  1. Configurar Tono del Canal 0
        PSG = 0x8B; // Byte bajo de tono
        PSG = 0x09; // Byte alto de tono
        // 2. Configurar Volumen del Canal 0  (0 = Máximo, 15 = Mute)
        PSG = 0x90; // 1001 0000 (Canal 0, Volumen Máximo)
        // 3. Esperar un momento (dejar sonar el beep)
        delay(100);
        // 4. Silenciar el Canal 0 (Volumen 15 = Silencio)
        PSG = 0x9F;
        // 3. Esperar un momento (en silencio)
        delay(100);
    }
#endif

/// @brief en el draw() la variable "vblank_ocurrido" es igual a "true"
/// @param delta
/// @param master
void draw(uint32_t delta, uint8_t master){
    // para evitar "parámetros sin usar": warning 85: in function draw unreferenced function argument : 'delta'
    delta;
    master;
    #if _TUTO3_1
        // Solo permite la primera posición 'y' (el primer tile)
        VDP_ADDRESS = (uint8_t)(_VRAM_SPRITE_INFO_Y & 0x00FF) + 0;                  // byte bajo
        VDP_ADDRESS = 0b01000000 | ((uint8_t)((_VRAM_SPRITE_INFO_Y >> 8) & 0x3F));  // byte alto
        VDP_DATA = yBall;
        VDP_DATA = _VRAM_SPRITE_END; // end of sprite list (sprite_y = 208)
        //  X
        //  Posición X e Índice: Base 0x3F80 (\(0x7F80\) para escribir)
        VDP_ADDRESS = (uint8_t)(_VRAM_SPRITE_INFO_X & 0x00FF) + 0;                  // byte bajo
        VDP_ADDRESS = 0b01000000 | ((uint8_t)((_VRAM_SPRITE_INFO_X >> 8) & 0x3F));  // byte alto
        VDP_DATA = xBall;
        VDP_DATA = 1; // AHORA MUESTRA EL TILE 1, OSEA EL SEGUNDO
    #endif
}

/// @brief en el update() la variable "vblank_ocurrido" es igual a "false"
/// @param delta
/// @param master
void update(uint32_t delta, uint8_t master){
    delta;
    master;
    #if _TUTO3_0 || _TUTO3_1
        if(moveBall()){
            #if _TUTO4_0
                beep();
            #endif
        }
    #endif
}


/** se ejecuta en cada ciclo de cpu. Para actualizaciones y cálculos rápidos, NADA de dibujo.
 * Activar/Desactivar alguna bandera y poco más.
 * en el update_fast() la variable "vblank_ocurrido" es igual a "false"*/
void update_fast(void){
    _DELTA++;
}

/// @brief el punto de entrada de nuestro código.
/// Al "draw()" lo llama la función "vblankISR()" durante el "V-Blank"
/// @param
void main(void){
    _PAUSE = false;
    while(1){ // ciclo infinito, no termina nunca el juego
        init();
        //playBeep(100, 2);
        loop();// si sale del loop esque ha cambiado de pantalla
    }
}

// by GuerraTron-26 <dinertron@gmail.com>