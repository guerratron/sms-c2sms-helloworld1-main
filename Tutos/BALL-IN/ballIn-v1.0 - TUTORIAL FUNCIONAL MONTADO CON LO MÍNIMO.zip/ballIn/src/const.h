#ifndef __CONST_H__
#define __CONST_H__

#include <defines.h>

// ------------------
// HABILITA O DESHABILITA EL NIVEL DE TUTORIAL (EMPEZAMOS EN TUTO1 CON TODO A 0)
#define _TUTO2_0 0 // CARGA EL FONDO
#define _TUTO2_1 0 // HABILITA EL DISPLAY
#define _TUTO2_2 0 // CARGA EL SPRITE
#define _TUTO3_0 0 // MUEVE COORDENADAS DEL SPRITE
#define _TUTO3_1 0 // ACTUALIZA EL DIBUJADO DEL SPRITE
#define _TUTO4_0 0 // SONIDO BEEP GRAVE
// ------------------

// GRAPHICS
/** Sprite "sBall"
sGraphic sBall; */
/** Límites rectangulares de "sBall"
oMove oBallMove; */


#endif