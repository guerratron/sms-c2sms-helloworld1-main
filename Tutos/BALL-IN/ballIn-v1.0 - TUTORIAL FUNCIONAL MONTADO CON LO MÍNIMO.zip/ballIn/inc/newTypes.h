#ifndef  __NEWTYPES_H__
#define  __NEWTYPES_H__

#ifndef  NULL
#define  NULL  ((void *) 0)
#endif

// boolean
#ifndef boolean
typedef enum {FALSE = 0, TRUE = 1} boolean;
#endif

// unsigned integer
#ifndef u8
typedef unsigned int u8;
#endif

// unsigned char
#ifndef byte
typedef unsigned char byte;
#endif

#endif