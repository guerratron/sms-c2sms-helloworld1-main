;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.5.0 #15242 (MINGW64)
;--------------------------------------------------------
	.module miniPong
	
	.optsdcc -mz80 sdcccall(1)
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _moveBall
	.globl __ballDef
	.globl __palBaseDef
	.globl _loop
	.globl _yIncr
	.globl _xIncr
	.globl _yBall
	.globl _xBall
	.globl __MASTER
	.globl __DELTA
	.globl _vblank_ocurrido
	.globl __PAUSE
	.globl __FINISH
	.globl _debounce_count
	.globl _vdp_status
	.globl _lives2
	.globl _lives1
	.globl _win2
	.globl _win1
	.globl _lastPoint
	.globl _point2
	.globl _point1
	.globl __ball_ani_clon
	.globl __ball_img_clon
	.globl __pal_base_clon
	.globl _oBallMove
	.globl _sBall
	.globl _vgm
	.globl __BUTTONS
	.globl __ball_til
	.globl __ball_ani
	.globl __ball_img
	.globl __pal_base
	.globl __bg_template_til
	.globl __bg_template_tilemap
	.globl __bg_template_pal
	.globl __VRAM_SPRITE_END
	.globl __VRAM_SPRITE_INFO_X
	.globl __VRAM_SPRITE_INFO_Y
	.globl __VRAM_TILES_TABLE
	.globl __VRAM_SPRITE_PATT
	.globl __VRAM_SPRITE_COL
	.globl __SPRITE_SIZE
	.globl __SPRITE_HEIGHT
	.globl __SPRITE_WIDTH
	.globl __SCREEN_TILES_SIZE
	.globl __SCREEN_TILES_HEIGHT
	.globl __SCREEN_TILES_WIDTH
	.globl __SCREEN_HEIGHT
	.globl __SCREEN_WIDTH
	.globl __TILE_BYTES_SIZE
	.globl __TILE_SIZE
	.globl __TILE_HEIGHT
	.globl __TILE_WIDTH
	.globl __MASTER_MAX
	.globl _delay
	.globl _isPress
	.globl _isSoftwarePause
	.globl _vgm_init
	.globl _vgm_tick
	.globl _load_music
	.globl _clear_vram
	.globl _write_palette
	.globl _write_vram
	.globl _write_vram_2
	.globl _draw_bg
	.globl _remove_bg
	.globl _vblankISR
	.globl _toVblankISR
	.globl _nmISR
	.globl _init
	.globl _draw
	.globl _update
	.globl _update_fast
	.globl _main
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_VDP_DATA	=	0x00be
_VDP_ADDRESS	=	0x00bf
_PSG	=	0x007f
__PAD1	=	0x00dc
__PAD2	=	0x00dd
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
__BUTTONS::
	.ds 1
_vgm::
	.ds 6
_sBall::
	.ds 25
_oBallMove::
	.ds 10
__pal_base_clon::
	.ds 16
__ball_img_clon::
	.ds 1
__ball_ani_clon::
	.ds 3
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
_point1::
	.ds 1
_point2::
	.ds 1
_lastPoint::
	.ds 1
_win1::
	.ds 1
_win2::
	.ds 1
_lives1::
	.ds 1
_lives2::
	.ds 1
_vdp_status::
	.ds 1
_debounce_count::
	.ds 1
__FINISH::
	.ds 1
__PAUSE::
	.ds 1
_vblank_ocurrido::
	.ds 1
__DELTA::
	.ds 4
__MASTER::
	.ds 1
_xBall::
	.ds 1
_yBall::
	.ds 1
_xIncr::
	.ds 1
_yIncr::
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;./inc/basic.h:26: void delay(uint16_t count) {
;	---------------------------------
; Function delay
; ---------------------------------
_delay::
;./inc/basic.h:28: for (i = 0; i < count; i++) {
	ld	bc, #0x0000
00103$:
	ld	a, c
	sub	a, l
	ld	a, b
	sbc	a, h
	ret	NC
;./inc/basic.h:29: __asm__("nop");
	nop
;./inc/basic.h:28: for (i = 0; i < count; i++) {
	inc	bc
;./inc/basic.h:31: }
	jr	00103$
__MASTER_MAX:
	.db #0xfe	; 254
__TILE_WIDTH:
	.db #0x08	; 8
__TILE_HEIGHT:
	.db #0x08	; 8
__TILE_SIZE:
	.db #0x40	; 64
__TILE_BYTES_SIZE:
	.db #0x20	; 32
__SCREEN_WIDTH:
	.db #0xff	; 255
__SCREEN_HEIGHT:
	.db #0xc0	; 192
__SCREEN_TILES_WIDTH:
	.db #0x20	; 32
__SCREEN_TILES_HEIGHT:
	.db #0x18	; 24
__SCREEN_TILES_SIZE:
	.dw #0x0300
__SPRITE_WIDTH:
	.db #0x04	; 4
__SPRITE_HEIGHT:
	.db #0x08	; 8
__SPRITE_SIZE:
	.db #0x20	; 32
__VRAM_SPRITE_COL:
	.dw #0x0000
__VRAM_SPRITE_PATT:
	.dw #0x2000
__VRAM_TILES_TABLE:
	.dw #0x3800
__VRAM_SPRITE_INFO_Y:
	.dw #0x3f00
__VRAM_SPRITE_INFO_X:
	.dw #0x3f80
__VRAM_SPRITE_END:
	.db #0xd0	; 208
;./inc/basic.h:39: uint8_t isPress(enum eBUTTONS button){ 
;	---------------------------------
; Function isPress
; ---------------------------------
_isPress::
;./inc/basic.h:40: uint8_t pad = _PAD1;
	push	af
	in	a, (__PAD1)
	ld	c, a
	pop	af
;./inc/basic.h:42: if(button == L2 || button == R2 || button == B12 || button == B22){
	cp	a, #0x81
	jr	Z, 00101$
	cp	a, #0x82
	jr	Z, 00101$
	cp	a, #0x84
	jr	Z, 00101$
	cp	a, #0x88
	jr	NZ, 00102$
00101$:
;./inc/basic.h:43: pad = _PAD2;
	push	af
	in	a, (__PAD2)
	ld	c, a
	pop	af
;./inc/basic.h:45: button &= 0b00001111; // LES ASIGNA SU VALOR CORRECTO (ESTABA DESPLAZADO)
	and	a, #0x0f
00102$:
;./inc/basic.h:47: if(button == res || button == inA){
	cp	a, #0x90
	jr	Z, 00106$
	cp	a, #0xc0
	jr	NZ, 00107$
00106$:
;./inc/basic.h:48: pad = _PAD2;
	push	af
	in	a, (__PAD2)
	ld	c, a
	pop	af
;./inc/basic.h:49: button &= 0b01010000; //LES ASIGNA SU VALOR CORRECTO (ESTABA DESPLAZADO)
	and	a, #0x50
00107$:
;./inc/basic.h:51: if(button == inB){
	cp	a, #0xc1
	jr	NZ, 00110$
;./inc/basic.h:52: pad = _PAD2;
	push	af
	in	a, (__PAD2)
	ld	c, a
	pop	af
;./inc/basic.h:53: button &= 0b01000001; //LES ASIGNA SU VALOR CORRECTO (ESTABA DESPLAZADO)
	and	a, #0x41
00110$:
;./inc/basic.h:55: return !(pad & button); //los botones se presionan a cero.
	and	a, c
	sub	a, #0x01
	ld	a, #0x00
	rla
;./inc/basic.h:67: }
	ret
;./inc/basic.h:72: bool isSoftwarePause(uint16_t count, uint16_t max){
;	---------------------------------
; Function isSoftwarePause
; ---------------------------------
_isSoftwarePause::
;./inc/basic.h:73: return ((count > max) && ((isPress(B1) && isPress(B2)) || (isPress(B12) && isPress(B22))));
	ld	a, e
	sub	a, l
	ld	a, d
	sbc	a, h
	jr	NC, 00103$
	ld	a, #0x10
	call	_isPress
	or	a, a
	jr	Z, 00111$
	ld	a, #0x20
	call	_isPress
	or	a, a
	jr	NZ, 00104$
00111$:
	ld	a, #0x84
	call	_isPress
	or	a, a
	jr	Z, 00103$
	ld	a, #0x88
	call	_isPress
	or	a, a
	jr	NZ, 00104$
00103$:
	xor	a, a
	ret
00104$:
	ld	a, #0x01
;./inc/basic.h:74: }
	ret
;./inc/basic.h:86: void vgm_init(vgm_info *vgm, const uint8_t *file_data){
;	---------------------------------
; Function vgm_init
; ---------------------------------
_vgm_init::
	push	ix
	ld	ix,#0
	add	ix,sp
	ld	iy, #-8
	add	iy, sp
	ld	sp, iy
	ld	-2 (ix), l
	ld	-1 (ix), h
;./inc/basic.h:87: uint32_t version = *((uint32_t *)(file_data + 0x08));
	push	de
	pop	iy
	ld	a, 8 (iy)
	ld	-6 (ix), a
	ld	a, 9 (iy)
	ld	-5 (ix), a
	ld	a, 10 (iy)
	ld	-4 (ix), a
	ld	a, 11 (iy)
	ld	-3 (ix), a
;./inc/basic.h:89: vgm->next_byte = file_data + 0x40;
	ld	c, -2 (ix)
	ld	b, -1 (ix)
	inc	bc
	inc	bc
	ld	hl, #0x0040
	add	hl, de
	ex	(sp), hl
;./inc/basic.h:88: if (version < 0x00000150){
	ld	a, -6 (ix)
	sub	a, #0x50
	ld	a, -5 (ix)
	sbc	a, #0x01
	ld	a, -4 (ix)
	sbc	a, #0x00
	ld	a, -3 (ix)
	sbc	a, #0x00
	jr	NC, 00105$
;./inc/basic.h:89: vgm->next_byte = file_data + 0x40;
	ld	l, c
	ld	h, b
	ld	a, -8 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -7 (ix)
	ld	(hl), a
	jr	00106$
00105$:
;./inc/basic.h:91: uint32_t data_offset = *((uint32_t *)(file_data + 0x34));
	ld	l, e
	ld	h, d
	push	de
	push	bc
	ex	de, hl
	ld	hl, #6
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0034
	add	hl, bc
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;./inc/basic.h:92: if (data_offset == 0x0000000C){
	ld	a, -6 (ix)
	sub	a, #0x0c
	or	a, -5 (ix)
	or	a, -4 (ix)
	or	a, -3 (ix)
	jr	NZ, 00102$
;./inc/basic.h:93: vgm->next_byte = file_data + 0x40;
	ld	l, c
	ld	h, b
	ld	a, -8 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -7 (ix)
	ld	(hl), a
	jr	00106$
00102$:
;./inc/basic.h:95: vgm->next_byte = file_data + data_offset + 0x34;
	ld	a, e
	add	a, -6 (ix)
	ld	e, a
	ld	a, d
	adc	a, -5 (ix)
	ld	d, a
	ld	hl, #0x0034
	add	hl, de
	ex	de, hl
	ld	l, c
	ld	h, b
	ld	(hl), e
	inc	hl
	ld	(hl), d
00106$:
;./inc/basic.h:98: vgm->first_byte = vgm->next_byte;
	ld	l, c
	ld	h, b
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
;./inc/basic.h:99: vgm->wait_counter = 0;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	de, #0x0004
	add	hl, de
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;./inc/basic.h:100: }
	ld	sp, ix
	pop	ix
	ret
;./inc/basic.h:105: void vgm_tick(vgm_info *vgm){
;	---------------------------------
; Function vgm_tick
; ---------------------------------
_vgm_tick::
	push	ix
	ld	ix,#0
	add	ix,sp
	ld	iy, #-20
	add	iy, sp
	ld	sp, iy
	ld	-2 (ix), l
	ld	-1 (ix), h
;./inc/basic.h:106: if (vgm->wait_counter > 0){
	ld	a, -2 (ix)
	add	a, #0x04
	ld	-20 (ix), a
	ld	a, -1 (ix)
	adc	a, #0x00
	ld	-19 (ix), a
	pop	hl
	push	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, b
	or	a, c
	jr	Z, 00102$
;./inc/basic.h:107: vgm->wait_counter--;
	dec	bc
	pop	hl
	push	hl
	ld	(hl), c
	inc	hl
	ld	(hl), b
;./inc/basic.h:108: return;
	jp	00123$
00102$:
;./inc/basic.h:110: const uint8_t *p = vgm->next_byte;
	ld	a, -2 (ix)
	add	a, #0x02
	ld	-18 (ix), a
	ld	a, -1 (ix)
	adc	a, #0x00
	ld	-17 (ix), a
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	a, (hl)
	ld	-16 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-15 (ix), a
;./inc/basic.h:111: if (*p == 0x50){
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	ld	a, (hl)
	sub	a, #0x50
	jr	NZ, 00114$
;./inc/basic.h:112: vgm->wait_counter = 0;
	pop	hl
	push	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;./inc/basic.h:113: while (*p == 0x50){
00103$:
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	ld	a, (hl)
	sub	a, #0x50
	jr	NZ, 00114$
;./inc/basic.h:114: p++;
	ld	c, -16 (ix)
	ld	b, -15 (ix)
	inc	bc
;./inc/basic.h:115: PSG = *p;
	ld	a, (bc)
	out	(_PSG), a
;./inc/basic.h:116: p++;
	inc	bc
	ld	-16 (ix), c
	ld	-15 (ix), b
	jr	00103$
;./inc/basic.h:119: while ((*p == 0x61) || (*p == 0x62) || (*p == 0x63)){
00114$:
;./inc/basic.h:111: if (*p == 0x50){
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	ld	c, (hl)
;./inc/basic.h:119: while ((*p == 0x61) || (*p == 0x62) || (*p == 0x63)){
	ld	a, c
	sub	a, #0x62
	ld	a, #0x01
	jr	Z, 00219$
	xor	a, a
00219$:
	ld	-6 (ix), a
	ld	a, c
	sub	a, #0x63
	ld	a, #0x01
	jr	Z, 00221$
	xor	a, a
00221$:
	ld	-5 (ix), a
	ld	a, c
	sub	a, #0x61
	jr	Z, 00115$
	ld	a, -6 (ix)
	or	a, a
	jr	NZ, 00115$
	ld	a, -5 (ix)
	or	a, a
	jp	Z, 00134$
00115$:
;./inc/basic.h:114: p++;
	ld	a, -16 (ix)
	add	a, #0x01
	ld	-4 (ix), a
	ld	a, -15 (ix)
	adc	a, #0x00
	ld	-3 (ix), a
;./inc/basic.h:120: if ((*p == 0x62) || (*p == 0x63)){
	ld	a, -6 (ix)
	or	a, a
	jr	NZ, 00108$
	ld	a, -5 (ix)
	or	a, a
	jr	Z, 00109$
00108$:
;./inc/basic.h:121: vgm->wait_counter++;
	pop	hl
	push	hl
	ld	a, (hl)
	ld	-8 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-7 (ix), a
	ld	a, -8 (ix)
	add	a, #0x01
	ld	-6 (ix), a
	ld	a, -7 (ix)
	adc	a, #0x00
	ld	-5 (ix), a
	pop	hl
	push	hl
	ld	a, -6 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -5 (ix)
	ld	(hl), a
;./inc/basic.h:122: p++;
	ld	a, -4 (ix)
	ld	-16 (ix), a
	ld	a, -3 (ix)
	ld	-15 (ix), a
	jp	00114$
00109$:
;./inc/basic.h:124: p++;
	ld	e, -4 (ix)
	ld	d, -3 (ix)
;./inc/basic.h:125: uint16_t num_samples = *((uint16_t *)p);
	ld	l, e
	ld	h, d
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
;./inc/basic.h:126: p += 2;
	inc	de
	inc	de
	ld	-16 (ix), e
	ld	-15 (ix), d
;./inc/basic.h:136: uint32_t aux = num_samples;
	ld	-14 (ix), c
	ld	-13 (ix), b
	xor	a, a
	ld	-12 (ix), a
	ld	-11 (ix), a
;./inc/basic.h:137: aux = ((aux << 14) + (aux << 12) + (aux << 8) + (aux << 5) + (aux << 2)) >> 24;
	ld	d, -14 (ix)
	ld	l, -13 (ix)
	ld	h, #0x00
	ld	e, h
	ld	b, #0x06
00223$:
	sla	d
	adc	hl, hl
	djnz	00223$
	ld	a, -14 (ix)
	ld	-5 (ix), a
	ld	a, -13 (ix)
	ld	-4 (ix), a
	ld	-3 (ix), #0x00
	ld	-6 (ix), #0x00
	ld	b, #0x04
00225$:
	sla	-5 (ix)
	rl	-4 (ix)
	rl	-3 (ix)
	djnz	00225$
	ld	a, d
	add	a, -5 (ix)
	ld	d, a
	ld	a, l
	adc	a, -4 (ix)
	ld	l, a
	ld	a, h
	adc	a, -3 (ix)
	ld	h, a
	ld	a, -14 (ix)
	ld	-5 (ix), a
	ld	a, -13 (ix)
	ld	-4 (ix), a
	ld	-3 (ix), #0x00
	ld	-6 (ix), #0x00
	ld	a, d
	add	a, -5 (ix)
	ld	d, a
	ld	a, l
	adc	a, -4 (ix)
	ld	l, a
	jr	NC, 00229$
	inc	h
00229$:
	ld	a, -14 (ix)
	ld	-10 (ix), a
	ld	a, -13 (ix)
	ld	-9 (ix), a
	ld	-8 (ix), #0x00
	ld	-7 (ix), #0x00
	ld	b, #0x05
00230$:
	sla	-10 (ix)
	rl	-9 (ix)
	rl	-8 (ix)
	rl	-7 (ix)
	djnz	00230$
	ld	a, e
	add	a, -10 (ix)
	ld	-6 (ix), a
	ld	a, d
	adc	a, -9 (ix)
	ld	-5 (ix), a
	ld	a, l
	adc	a, -8 (ix)
	ld	-4 (ix), a
	ld	a, h
	adc	a, -7 (ix)
	ld	-3 (ix), a
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	ld	de, #0x0
	ld	b, #0x02
00232$:
	add	hl, hl
	rl	e
	rl	d
	djnz	00232$
	ld	a, -6 (ix)
	add	a, l
	ld	a, -5 (ix)
	adc	a, h
	ld	a, -4 (ix)
	adc	a, e
	ld	a, -3 (ix)
	adc	a, d
	ld	c, a
	ld	b, #0x00
;./inc/basic.h:138: vgm->wait_counter = aux;
	pop	hl
	push	hl
	ld	(hl), c
	inc	hl
	ld	(hl), b
	jp	00114$
;./inc/basic.h:141: while ((*p & 0x70) == 0x70){
00134$:
	ld	c, -16 (ix)
	ld	b, -15 (ix)
00117$:
	ld	a, (bc)
	ld	e, a
	and	a, #0x70
	sub	a, #0x70
	jr	NZ, 00119$
;./inc/basic.h:143: p++;
	inc	bc
	jr	00117$
00119$:
;./inc/basic.h:145: if (*p == 0x66){
	ld	a, e
	sub	a, #0x66
	jr	NZ, 00121$
;./inc/basic.h:146: vgm->wait_counter = 0;
	pop	hl
	push	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;./inc/basic.h:147: vgm->next_byte = vgm->first_byte;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	pop	de
	pop	hl
	push	hl
	push	de
	ld	(hl), c
	inc	hl
	ld	(hl), b
	jr	00123$
00121$:
;./inc/basic.h:149: vgm->next_byte = p;
	pop	de
	pop	hl
	push	hl
	push	de
	ld	(hl), c
	inc	hl
	ld	(hl), b
00123$:
;./inc/basic.h:151: }
	ld	sp, ix
	pop	ix
	ret
;./inc/basic.h:156: void load_music(uint8_t *mus){
;	---------------------------------
; Function load_music
; ---------------------------------
_load_music::
	ex	de, hl
;./inc/basic.h:157: vgm_init(&vgm, mus); // vgm es una estructura de tipo "vgm_info" definida en "defines.h"
	ld	hl, #_vgm
;./inc/basic.h:158: }
	jp	_vgm_init
;./inc/basic.h:164: void clear_vram(uint8_t fill) {
;	---------------------------------
; Function clear_vram
; ---------------------------------
_clear_vram::
	ld	c, a
;./inc/basic.h:168: VDP_ADDRESS = 0x00; // start at color 0
	xor	a, a
	out	(_VDP_ADDRESS), a
;./inc/basic.h:169: VDP_ADDRESS = 0x40; //0b01000000; // 64 // 0x40
	ld	a, #0x40
	out	(_VDP_ADDRESS), a
;./inc/basic.h:174: for(i = 0; i < 16384; i++) {
	ld	de, #0x0000
00102$:
;./inc/basic.h:175: VDP_DATA = fill;//0x00;
	ld	a, c
	out	(_VDP_DATA), a
;./inc/basic.h:174: for(i = 0; i < 16384; i++) {
	inc	de
	ld	a, d
	sub	a, #0x40
	jr	C, 00102$
;./inc/basic.h:177: }
	ret
;./inc/basic.h:181: void write_palette(uint8_t offset, const uint8_t *palette){
;	---------------------------------
; Function write_palette
; ---------------------------------
_write_palette::
	out	(_VDP_ADDRESS), a
	ld	c, e
	ld	b, d
;./inc/basic.h:183: VDP_ADDRESS = 0b11000000; // 192 // 0xc0 
	ld	a, #0xc0
	out	(_VDP_ADDRESS), a
;./inc/basic.h:185: while (n > 0){
	ld	e, #0x10
00101$:
	ld	a, e
	or	a, a
	ret	Z
;./inc/basic.h:186: VDP_DATA = *palette;
	ld	a, (bc)
	out	(_VDP_DATA), a
;./inc/basic.h:187: palette++;
	inc	bc
;./inc/basic.h:188: n--;
	dec	e
;./inc/basic.h:190: }
	jr	00101$
;./inc/basic.h:194: void write_vram(const uint8_t *src, uint16_t size, uint16_t vram_addr){
;	---------------------------------
; Function write_vram
; ---------------------------------
_write_vram::
	push	ix
	ld	ix,#0
	add	ix,sp
	ld	c, l
	ld	b, h
;./inc/basic.h:195: VDP_ADDRESS = (uint8_t)(vram_addr & 0x00FF);
	ld	a, 4 (ix)
	out	(_VDP_ADDRESS), a
;./inc/basic.h:196: VDP_ADDRESS = 0b01000000 | ((uint8_t)((vram_addr >> 8) & 0x3F));
	ld	a, 5 (ix)
	and	a, #0x3f
	or	a, #0x40
	out	(_VDP_ADDRESS), a
;./inc/basic.h:197: while (size > 0){
00101$:
	ld	a, d
	or	a, e
	jr	Z, 00104$
;./inc/basic.h:198: VDP_DATA = *src;
	ld	a, (bc)
	out	(_VDP_DATA), a
;./inc/basic.h:199: src++;
	inc	bc
;./inc/basic.h:200: size--;
	dec	de
	jr	00101$
00104$:
;./inc/basic.h:202: }
	pop	ix
	pop	hl
	pop	af
	jp	(hl)
;./inc/basic.h:205: void write_vram_2(const uint8_t *src, uint16_t size, uint16_t vram_addr){
;	---------------------------------
; Function write_vram_2
; ---------------------------------
_write_vram_2::
	push	ix
	ld	ix,#0
	add	ix,sp
	ld	c, l
	ld	b, h
;./inc/basic.h:206: VDP_ADDRESS = (uint8_t)(vram_addr & 0x00FF);
	ld	a, 4 (ix)
	out	(_VDP_ADDRESS), a
;./inc/basic.h:207: VDP_ADDRESS = 0b01000000 | ((uint8_t)((vram_addr >> 8) & 0x3F));
	ld	a, 5 (ix)
	and	a, #0x3f
	or	a, #0x40
	out	(_VDP_ADDRESS), a
;./inc/basic.h:208: while (size > 0){
00101$:
	ld	a, d
	or	a, e
	jr	Z, 00104$
;./inc/basic.h:209: VDP_DATA = *src;
	ld	a, (bc)
	out	(_VDP_DATA), a
;./inc/basic.h:210: VDP_DATA = 0;
	xor	a, a
	out	(_VDP_DATA), a
;./inc/basic.h:211: src++;
	inc	bc
;./inc/basic.h:212: size--;
	dec	de
	jr	00101$
00104$:
;./inc/basic.h:214: }
	pop	ix
	pop	hl
	pop	af
	jp	(hl)
;./inc/basic.h:217: void draw_bg(uint8_t *pal, uint8_t *tiles, uint16_t size, uint8_t *tilemap){
;	---------------------------------
; Function draw_bg
; ---------------------------------
_draw_bg::
;./inc/basic.h:220: write_palette(PALETTE_OFFSET_TILES, pal);
	ex	de, hl
	push	hl
	xor	a, a
	call	_write_palette
	pop	bc
;./inc/basic.h:221: write_vram(tiles, size, 0);                        // 3 * 4 * 8, 0); // 240 + 1 tile patterns --> vram pattern address (0x0000)
	ld	hl, #0x0000
	push	hl
	ld	hl, #4
	add	hl, sp
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, c
	ld	h, b
	call	_write_vram
;./inc/basic.h:222: write_vram_2(tilemap, _SCREEN_TILES_SIZE, 0x3800); // 32 * 24 tiles --> vram tile map address (0x3800)
	ld	hl, #0x3800
	push	hl
	ld	de, #0x0300
	ld	hl, #6
	add	hl, sp
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	call	_write_vram_2
;./inc/basic.h:224: }
	pop	hl
	pop	af
	pop	af
	jp	(hl)
;./inc/basic.h:227: void remove_bg(void){
;	---------------------------------
; Function remove_bg
; ---------------------------------
_remove_bg::
	ld	hl, #-1024
	add	hl, sp
	ld	sp, hl
;./inc/basic.h:229: memset(tiles, 0, 256); //
	ld	hl, #0
	add	hl, sp
	ld	e, l
	ld	d, h
	ld	b, #0x80
00103$:
	ld	(hl), #0x00
	inc	hl
	ld	(hl), #0x00
	inc	hl
	djnz	00103$
;./inc/basic.h:230: write_vram(tiles, 1, 0); // --> vram pattern address (0x0000)
	ex	de, hl
	ld	de, #0x0000
	push	de
	ld	de, #0x0001
	call	_write_vram
;./inc/basic.h:232: memset(tilemap, 0, _SCREEN_TILES_SIZE); // 32 * 24;
	ld	hl, #256
	add	hl, sp
	ld	(hl), #0x00
	push	hl
	ld	e, l
	ld	d, h
	inc	de
	ld	bc, #0x02ff
	ldir
	pop	de
;./inc/basic.h:233: write_vram_2(tilemap, _SCREEN_TILES_SIZE, 0x3800); // 32 * 24 (768) tiles --> vram tile map address (0x3800)
	ex	de, hl
	ld	de, #0x3800
	push	de
	ld	de, #0x0300
	call	_write_vram_2
;./inc/basic.h:235: }
	ld	hl, #1024
	add	hl, sp
	ld	sp, hl
	ret
;./inc/basic.h:260: void vblankISR(void) __critical __interrupt(0){
;	---------------------------------
; Function vblankISR
; ---------------------------------
_vblankISR::
	push	af
	push	bc
	push	de
	push	hl
	push	iy
;./inc/basic.h:262: vblank_ocurrido = true;
	ld	hl, #_vblank_ocurrido
	ld	(hl), #0x01
;./inc/basic.h:263: vdp_status = VDP_ADDRESS;
	in	a, (_VDP_ADDRESS)
	ld	(_vdp_status+0), a
;./inc/basic.h:264: }
	pop	iy
	pop	hl
	pop	de
	pop	bc
	pop	af
	ei
	reti
;./inc/basic.h:274: void toVblankISR(void){
;	---------------------------------
; Function toVblankISR
; ---------------------------------
_toVblankISR::
;./inc/basic.h:275: __asm__("di"); //; Des-Habilitar interrupciones
	di
;./inc/basic.h:277: if (!_PAUSE){
	ld	iy, #__PAUSE
	bit	0, 0 (iy)
	jr	NZ, 00104$
;./inc/basic.h:280: draw(_DELTA, _MASTER); // main.h
	ld	a, (__MASTER)
	push	af
	inc	sp
	ld	de, (__DELTA)
	ld	hl, (__DELTA + 2)
	call	_draw
;./inc/basic.h:282: _MASTER++;
	ld	iy, #__MASTER
	inc	0 (iy)
;./inc/basic.h:283: if(_MASTER > _MASTER_MAX){ _MASTER = 0; }
	ld	a, #0xfe
	sub	a, 0 (iy)
	jr	NC, 00104$
	ld	0 (iy), #0x00
00104$:
;./inc/basic.h:285: _DELTA = 0;
	xor	a, a
	ld	(__DELTA+0), a
	ld	(__DELTA+1), a
	ld	(__DELTA+2), a
	ld	(__DELTA+3), a
;./inc/basic.h:286: __asm__("ei"); //; Habilitar interrupciones
	ei
;./inc/basic.h:289: vdp_status = VDP_ADDRESS;
	in	a, (_VDP_ADDRESS)
	ld	(_vdp_status+0), a
;./inc/basic.h:291: vblank_ocurrido = false;
	xor	a, a
	ld	(_vblank_ocurrido+0), a
;./inc/basic.h:292: }
	ret
;./inc/basic.h:297: void nmISR(void) __critical __interrupt(1) {}
;	---------------------------------
; Function nmISR
; ---------------------------------
_nmISR::
	ei
	reti
;./inc/main.h:52: void loop(void){
;	---------------------------------
; Function loop
; ---------------------------------
_loop::
;./inc/main.h:55: while (!vblank_ocurrido){
00101$:
	ld	hl, #_vblank_ocurrido
	bit	0, (hl)
	jr	NZ, 00103$
;./inc/main.h:56: update_fast();
	call	_update_fast
	jr	00101$
00103$:
;./inc/main.h:60: toVblankISR();
	call	_toVblankISR
;./inc/main.h:64: if (!_PAUSE){
	ld	hl, #__PAUSE
	bit	0, (hl)
	jr	NZ, 00101$
;./inc/main.h:71: update(_DELTA, _MASTER);
	ld	a, (__MASTER)
	push	af
	inc	sp
	ld	de, (__DELTA)
	ld	hl, (__DELTA + 2)
	call	_update
;./inc/main.h:74: }
	jr	00101$
;./assets/sprites/pal_base_def.h:46: sGraphic *_palBaseDef(sGraphic *sG){
;	---------------------------------
; Function _palBaseDef
; ---------------------------------
__palBaseDef::
;./assets/sprites/pal_base_def.h:52: memcpy(_pal_base_clon, _pal_base, _pal_base_size);
	push	hl
	ld	de, #__pal_base_clon
	ld	hl, #__pal_base
	ld	bc, #0x0010
	ldir
	pop	de
;./assets/sprites/pal_base_def.h:53: sG->pal = _pal_base_clon;
	ld	hl, #0x0006
	add	hl, de
	ld	(hl), #<(__pal_base_clon)
	inc	hl
	ld	(hl), #>(__pal_base_clon)
;./assets/sprites/pal_base_def.h:60: return sG;
;./assets/sprites/pal_base_def.h:61: }
	ret
__bg_template_pal:
	.db #0x3a	; 58
	.db #0x25	; 37
__bg_template_tilemap:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
__bg_template_til:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x02	; 2
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x08	; 8
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x18	; 24
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x24	; 36
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x42	; 66	'B'
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x81	; 129
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfe	; 254
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfd	; 253
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xfb	; 251
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xf7	; 247
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xe7	; 231
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xdb	; 219
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0xbd	; 189
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
__pal_base:
	.db #0x00	; 0
	.db #0x04	; 4
	.db #0x24	; 36
	.db #0x10	; 16
	.db #0x14	; 20
	.db #0x06	; 6
	.db #0x02	; 2
	.db #0x01	; 1
	.db #0x11	; 17
	.db #0x15	; 21
	.db #0x0b	; 11
	.db #0x1f	; 31
	.db #0x3f	; 63
	.db 0x00
	.db 0x00
	.db 0x00
;./assets/sprites/ball_def.h:184: sGraphic *_ballDef(sGraphic *sG, const uint8_t id, const uint8_t xAddress, const uint8_t yAddress, const uint16_t prev_tiles, const uint8_t x, const uint8_t y, oMove *oM, sJumpV *sJ){
;	---------------------------------
; Function _ballDef
; ---------------------------------
__ballDef::
	push	ix
	ld	ix,#0
	add	ix,sp
	ld	iy, #-9
	add	iy, sp
	ld	sp, iy
;./assets/sprites/ball_def.h:193: _palBaseDef(sG); // establece "sG->pal"
	push	hl
	call	__palBaseDef
;./assets/sprites/ball_def.h:195: memcpy(_ball_img_clon, _ball_img, _ball_img_size);
	ld	de, #__ball_img_clon
	ld	a, (#__ball_img)
	ld	(de), a
;./assets/sprites/ball_def.h:197: memcpy(_ball_ani_clon, _ball_ani, _ball_ani_size);
	ld	de, #__ball_ani_clon
	ld	hl, #__ball_ani
	ld	bc, #0x0003
	ldir
	pop	de
;./assets/sprites/ball_def.h:198: sG->id = id;
	ld	a, 4 (ix)
	ld	(de), a
;./assets/sprites/ball_def.h:199: sG->xAddress = xAddress;
	ld	c, e
	ld	b, d
	inc	bc
	ld	a, 5 (ix)
	ld	(bc), a
;./assets/sprites/ball_def.h:200: sG->yAddress = yAddress;
	ld	c, e
	ld	b, d
	inc	bc
	inc	bc
	ld	a, 6 (ix)
	ld	(bc), a
;./assets/sprites/ball_def.h:201: sG->prevTiles = prev_tiles;
	ld	hl, #0x0003
	add	hl, de
	ld	-7 (ix), l
	ld	-6 (ix), h
	ld	a, 7 (ix)
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	(hl), a
;./assets/sprites/ball_def.h:202: sG->x = x;
	ld	hl, #0x0004
	add	hl, de
	ld	a, 9 (ix)
	ld	(hl), a
;./assets/sprites/ball_def.h:203: sG->y = y;
	ld	hl, #0x0005
	add	hl, de
	ld	a, 10 (ix)
	ld	(hl), a
;./assets/sprites/ball_def.h:205: sG->tiles = _ball_til;
	ld	hl, #0x000b
	add	hl, de
	ld	bc, #__ball_til+0
	ld	(hl), c
	inc	hl
	ld	(hl), b
;./assets/sprites/ball_def.h:206: sG->size = _ball_size;
	ld	hl, #0x0009
	add	hl, de
	ld	(hl), #0x60
	inc	hl
	ld	(hl), #0x00
;./assets/sprites/ball_def.h:207: sG->nTiles = _ball_ntiles;
	ld	hl, #0x0008
	add	hl, de
	ld	(hl), #0x03
;./assets/sprites/ball_def.h:208: sG->img = _ball_img_clon;
	ld	hl, #0x000d
	add	hl, de
	ex	(sp), hl
	pop	hl
	ld	(hl), #<(__ball_img_clon)
	push	hl
	inc	hl
	ld	(hl), #>(__ball_img_clon)
;./assets/sprites/ball_def.h:209: sG->w = _ball_img_w;
	ld	hl, #0x000f
	add	hl, de
	ld	(hl), #0x01
;./assets/sprites/ball_def.h:210: sG->h = _ball_img_h;
	ld	hl, #0x0010
	add	hl, de
	ld	(hl), #0x01
;./assets/sprites/ball_def.h:211: sG->i = 0;
	ld	hl, #0x0011
	add	hl, de
	ld	(hl), #0x00
;./assets/sprites/ball_def.h:212: sG->ani_size = _ball_ani_size;
	ld	hl, #0x0014
	add	hl, de
	ld	-5 (ix), l
	ld	-4 (ix), h
	ld	(hl), #0x03
;./assets/sprites/ball_def.h:213: sG->ani = _ball_ani_clon;
	ld	hl, #0x0012
	add	hl, de
	ld	-3 (ix), l
	ld	-2 (ix), h
	ld	(hl), #<(__ball_ani_clon)
	inc	hl
	ld	(hl), #>(__ball_ani_clon)
;./assets/sprites/ball_def.h:214: sG->oM = oM;
	ld	hl, #0x0015
	add	hl, de
	ld	a, 11 (ix)
	ld	(hl), a
	inc	hl
	ld	a, 12 (ix)
	ld	(hl), a
;./assets/sprites/ball_def.h:215: sG->sJ = sJ;
	ld	hl, #0x0017
	add	hl, de
	ld	a, 13 (ix)
	ld	(hl), a
	inc	hl
	ld	a, 14 (ix)
	ld	(hl), a
	dec	hl
;./assets/sprites/ball_def.h:216: if (sG->sJ){
	ld	a, 14 (ix)
	or	a, 13 (ix)
	jr	Z, 00113$
;./assets/sprites/ball_def.h:217: sG->sJ->is_jumping = _ball_is_jumping;
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	dec	hl
	xor	a, a
	ld	(bc), a
;./assets/sprites/ball_def.h:218: sG->sJ->jump_velocity = _ball_jump_velocity; // 0;
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	dec	hl
	inc	bc
	xor	a, a
	ld	(bc), a
	inc	bc
	ld	(bc), a
;./assets/sprites/ball_def.h:219: sG->sJ->ground_y = _ball_ground_y;           // 120; // Nivel del suelo
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	dec	hl
	inc	bc
	inc	bc
	inc	bc
	ld	a, #0x78
	ld	(bc), a
;./assets/sprites/ball_def.h:220: sG->sJ->gravity = _ball_gravity;             // 1;    // Fuerza de gravedad (ajustable)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	hl, #0x0004
	add	hl, bc
	ld	(hl), #0x01
	inc	hl
	ld	(hl), #0x00
;./assets/sprites/ball_def.h:225: for (i = 0; i < _ball_img_size; i++){
00113$:
	ld	-1 (ix), #0x00
00105$:
;./assets/sprites/ball_def.h:226: sG->img[i] += sG->prevTiles;
	pop	hl
	push	hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, -1 (ix)
	add	a, c
	ld	c, a
	ld	a, #0x00
	adc	a, b
	ld	b, a
	ld	a, (bc)
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	l, (hl)
	add	a, l
	ld	(bc), a
;./assets/sprites/ball_def.h:225: for (i = 0; i < _ball_img_size; i++){
	inc	-1 (ix)
	ld	a, -1 (ix)
	xor	a, #0x80
	sub	a, #0x81
	jr	C, 00105$
;./assets/sprites/ball_def.h:229: for (i = 0; i < sG->ani_size; i++){
	ld	-1 (ix), #0x00
00108$:
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	ld	c, (hl)
	ld	a, -1 (ix)
	sub	a, c
	jr	NC, 00104$
;./assets/sprites/ball_def.h:230: sG->ani[i] += sG->prevTiles;
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, c
	add	a, -1 (ix)
	ld	c, a
	jr	NC, 00149$
	inc	b
00149$:
	ld	a, (bc)
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	l, (hl)
	add	a, l
	ld	(bc), a
;./assets/sprites/ball_def.h:229: for (i = 0; i < sG->ani_size; i++){
	inc	-1 (ix)
	jr	00108$
00104$:
;./assets/sprites/ball_def.h:232: return sG;
;./assets/sprites/ball_def.h:233: }
	ld	sp, ix
	pop	ix
	pop	hl
	pop	af
	pop	af
	pop	af
	pop	af
	pop	af
	inc	sp
	jp	(hl)
__ball_img:
	.db #0x00	; 0
__ball_ani:
	.db #0x00	; 0
	.db #0x01	; 1
	.db #0x02	; 2
__ball_til:
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x10	; 16
	.db #0x72	; 114	'r'
	.db #0x0c	; 12
	.db #0x7e	; 126
	.db #0x30	; 48	'0'
	.db #0x72	; 114	'r'
	.db #0x0c	; 12
	.db #0x7e	; 126
	.db #0x3c	; 60
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x18	; 24
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x10	; 16
	.db #0xf3	; 243
	.db #0x0c	; 12
	.db #0xff	; 255
	.db #0x30	; 48	'0'
	.db #0xf3	; 243
	.db #0x0c	; 12
	.db #0xff	; 255
	.db #0x3c	; 60
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x18	; 24
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0xff	; 255
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x66	; 102	'f'
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x42	; 66	'B'
	.db #0x66	; 102	'f'
	.db #0x18	; 24
	.db #0x7e	; 126
	.db #0x42	; 66	'B'
	.db #0x66	; 102	'f'
	.db #0x18	; 24
	.db #0x7e	; 126
	.db #0x66	; 102	'f'
	.db #0x7e	; 126
	.db #0x00	; 0
	.db #0x7e	; 126
	.db #0x3c	; 60
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x3c	; 60
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
;src/miniPong.c:35: void init(void){
;	---------------------------------
; Function init
; ---------------------------------
_init::
;src/miniPong.c:37: __asm__("di"); //; Des-Habilitar interrupciones
	di
;src/miniPong.c:39: VDP_ADDRESS = 0b00100000; // 0x20; // 32
	ld	a, #0x20
	out	(_VDP_ADDRESS), a
;src/miniPong.c:40: VDP_ADDRESS = 0x81;
	ld	a, #0x81
	out	(_VDP_ADDRESS), a
;src/miniPong.c:45: write_palette(PALETTE_OFFSET_TILES, _bg_template_pal);
	ld	de, #__bg_template_pal
	xor	a, a
	call	_write_palette
;src/miniPong.c:46: write_vram(_bg_template_til, _bg_template_size, 0);
	ld	hl, #0x0000
	push	hl
	ld	de, #0x0060
	ld	hl, #__bg_template_til
	call	_write_vram
;src/miniPong.c:47: write_vram_2(_bg_template_tilemap, _bg_template_tilemap_size, 0x3800);
	ld	hl, #0x3800
	push	hl
	ld	de, #0x0300
	ld	hl, #__bg_template_tilemap
	call	_write_vram_2
;src/miniPong.c:51: write_palette(PALETTE_OFFSET_SPRITES, _pal_base);
	ld	de, #__pal_base
	ld	a, #0x10
	call	_write_palette
;src/miniPong.c:52: write_vram(_ball_til, _ball_size, _VRAM_SPRITE_PATT);
	ld	hl, #0x2000
	push	hl
	ld	de, #0x0060
	ld	hl, #__ball_til
	call	_write_vram
;src/miniPong.c:57: VDP_ADDRESS = 0b01100000; // 0x60; // 96
	ld	a, #0x60
	out	(_VDP_ADDRESS), a
;src/miniPong.c:58: VDP_ADDRESS = 0x81;
	ld	a, #0x81
	out	(_VDP_ADDRESS), a
;src/miniPong.c:59: __asm__("ei"); //; Habilitar interrupciones
	ei
;src/miniPong.c:63: xBall = 0;
;src/miniPong.c:64: yBall = 0;
	xor	a, a
	ld	(_xBall+0), a
	ld	(_yBall+0), a
;src/miniPong.c:65: xIncr = 1;
	ld	hl, #_xIncr
	ld	(hl), #0x01
;src/miniPong.c:66: yIncr = 1;
	ld	hl, #_yIncr
	ld	(hl), #0x01
;src/miniPong.c:68: }
	ret
;src/miniPong.c:81: bool moveBall(void){
;	---------------------------------
; Function moveBall
; ---------------------------------
_moveBall::
;src/miniPong.c:82: bool result = false;
	ld	c, #0x00
;src/miniPong.c:83: xBall += xIncr;
	ld	hl, #_xBall
	ld	a, (hl)
	ld	iy, #_xIncr
	add	a, 0 (iy)
	ld	(hl), a
;src/miniPong.c:84: if ((xBall >= _SCREEN_WIDTH - 8) || (xBall <= 0)){
	ld	a, (_xBall)
	sub	a, #0xf7
	jr	NC, 00101$
	ld	a, (_xBall+0)
	or	a, a
	jr	NZ, 00102$
00101$:
;src/miniPong.c:85: xIncr *= -1;
	ld	hl, #_xIncr
	xor	a, a
	sub	a, (hl)
	ld	(hl), a
;src/miniPong.c:86: result = true;
	ld	c, #0x01
00102$:
;src/miniPong.c:88: yBall += yIncr;
	ld	hl, #_yBall
	ld	a, (hl)
	ld	iy, #_yIncr
	add	a, 0 (iy)
	ld	(hl), a
;src/miniPong.c:89: if ((yBall >= _SCREEN_HEIGHT - 8) || (yBall <= 0)){
	ld	a, (_yBall)
	sub	a, #0xb8
	jr	NC, 00104$
	ld	a, (_yBall+0)
	or	a, a
	jr	NZ, 00105$
00104$:
;src/miniPong.c:90: yIncr *= -1;
	ld	hl, #_yIncr
	xor	a, a
	sub	a, (hl)
	ld	(hl), a
;src/miniPong.c:91: result = true;
	ld	c, #0x01
00105$:
;src/miniPong.c:93: return result;
	ld	a, c
;src/miniPong.c:94: }
	ret
;src/miniPong.c:117: void draw(uint32_t delta, uint8_t master){
;	---------------------------------
; Function draw
; ---------------------------------
_draw::
;src/miniPong.c:123: VDP_ADDRESS = (uint8_t)(_VRAM_SPRITE_INFO_Y & 0x00FF) + 0;                  // byte bajo
	xor	a, a
	out	(_VDP_ADDRESS), a
;src/miniPong.c:124: VDP_ADDRESS = 0b01000000 | ((uint8_t)((_VRAM_SPRITE_INFO_Y >> 8) & 0x3F));  // byte alto
	ld	a, #0x3f
	and	a, #0x3f
	or	a, #0x40
	out	(_VDP_ADDRESS), a
;src/miniPong.c:125: VDP_DATA = yBall;
	ld	a, (_yBall+0)
	out	(_VDP_DATA), a
;src/miniPong.c:126: VDP_DATA = _VRAM_SPRITE_END; // end of sprite list (sprite_y = 208)
	ld	a, #0xd0
	out	(_VDP_DATA), a
;src/miniPong.c:129: VDP_ADDRESS = (uint8_t)(_VRAM_SPRITE_INFO_X & 0x00FF) + 0;                  // byte bajo
	ld	a, #0x80
	out	(_VDP_ADDRESS), a
;src/miniPong.c:130: VDP_ADDRESS = 0b01000000 | ((uint8_t)((_VRAM_SPRITE_INFO_X >> 8) & 0x3F));  // byte alto
	ld	a, #0x3f
	and	a, #0x3f
	or	a, #0x40
	out	(_VDP_ADDRESS), a
;src/miniPong.c:131: VDP_DATA = xBall;
	ld	a, (_xBall+0)
	out	(_VDP_DATA), a
;src/miniPong.c:132: VDP_DATA = 1; // AHORA MUESTRA EL TILE 1, OSEA EL SEGUNDO
	ld	a, #0x01
	out	(_VDP_DATA), a
;src/miniPong.c:134: }
	pop	hl
	inc	sp
	jp	(hl)
;src/miniPong.c:139: void update(uint32_t delta, uint8_t master){
;	---------------------------------
; Function update
; ---------------------------------
_update::
;src/miniPong.c:143: if(moveBall()){
	call	_moveBall
;src/miniPong.c:149: }
	pop	hl
	inc	sp
	jp	(hl)
;src/miniPong.c:155: void update_fast(void){
;	---------------------------------
; Function update_fast
; ---------------------------------
_update_fast::
;src/miniPong.c:156: _DELTA++;
	ld	iy, #__DELTA
	inc	0 (iy)
	ret	NZ
	inc	1 (iy)
	ret	NZ
	inc	2 (iy)
	ret	NZ
	inc	3 (iy)
;src/miniPong.c:157: }
	ret
;src/miniPong.c:162: void main(void){
;	---------------------------------
; Function main
; ---------------------------------
_main::
;src/miniPong.c:163: _PAUSE = false;
	xor	a, a
	ld	(__PAUSE+0), a
;src/miniPong.c:164: while(1){ // ciclo infinito, no termina nunca el juego
00102$:
;src/miniPong.c:165: init();
	call	_init
;src/miniPong.c:167: loop();// si sale del loop esque ha cambiado de pantalla
	call	_loop
;src/miniPong.c:169: }
	jr	00102$
	.area _CODE
	.area _INITIALIZER
__xinit__point1:
	.db #0x00	; 0
__xinit__point2:
	.db #0x00	; 0
__xinit__lastPoint:
	.db #0x00	; 0
__xinit__win1:
	.db #0x00	;  0
__xinit__win2:
	.db #0x00	;  0
__xinit__lives1:
	.db #0x03	; 3
__xinit__lives2:
	.db #0x03	; 3
__xinit__vdp_status:
	.db #0x00	; 0
__xinit__debounce_count:
	.db #0x00	; 0
__xinit___FINISH:
	.db #0x00	;  0
__xinit___PAUSE:
	.db #0x00	;  0
__xinit__vblank_ocurrido:
	.db #0x00	;  0
__xinit___DELTA:
	.byte #0x00, #0x00, #0x00, #0x00	; 0
__xinit___MASTER:
	.db #0x00	; 0
__xinit__xBall:
	.db #0x00	; 0
__xinit__yBall:
	.db #0x00	; 0
__xinit__xIncr:
	.db #0x01	; 1
__xinit__yIncr:
	.db #0x01	; 1
	.area _CABS (ABS)
