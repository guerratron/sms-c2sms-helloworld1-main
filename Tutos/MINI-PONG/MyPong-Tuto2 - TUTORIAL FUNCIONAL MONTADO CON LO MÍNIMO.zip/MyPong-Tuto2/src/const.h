#ifndef __CONST_H__
#define __CONST_H__

#include <defines.h>

// ----------------------------------------------------
// TRABAJAR EN EL TUTO ACTIVANDO O DESACTIVANDO DEFINES
// ----------------------------------------------------
/// cargamos un fondo
#define _TUTO2_COMMONS_1 0
/// carga sprites: pelota, raquetas, marcadores, logo, ..
#define _TUTO2_COMMONS_2 0
/// visualizamos sprites sobre el fondo de la pantalla
#define _TUTO2_COMMONS_3 0

/// dibuja el fondo y emite un breve pitido
#define _TUTO2_INTRO_1 0
/// dibuja objetos gráficos "raquetas, bola, marcadores, logo, .." (es más visible si desactivamos _TUTO2_COMMONS_2)
#define _TUTO2_INTRO_2 0
/// comprueba la pulsación de botones en el "update"
#define _TUTO2_INTRO_3 0

/// reconoce la pantalla y la añade al array de las existentes
#define _TUTO2_PLAY_1 0
/// control del movimiento de la bola y los marcadores
#define _TUTO2_PLAY_2 0
/// control del movimiento del logo y de los pads (con cursor) 
#define _TUTO2_PLAY_3 0
/// control de colisiones 
#define _TUTO2_PLAY_4 0
/// activa pasar de pantalla (a gameover, pero aún no existe)
#define _TUTO2_PLAY_5 0

/// reconoce la pantalla y la añade al array de las existentes
#define _TUTO2_GAMEOVER_1 0
/// cargamos los gráficos (fondo, raquetas y logo)
#define _TUTO2_GAMEOVER_2 0
/// detección de botones para volver a pantalla inicial
#define _TUTO2_GAMEOVER_3 0
// ----------------------------------------------------

// GRAPHICS-OBJECTS
/** Sprite "sBall" */
sGraphic sBall;
/** Límites rectangulares de "sBall" */
oMove oBallMove;

/** Sprite "sMark1" */
sGraphic sMark1;
/** Límites rectangulares de "sMark1" */
oMove oMark1Move;

/** Sprite "sMark2" */
sGraphic sMark2;
/** Límites rectangulares de "sMark2" */
oMove oMark2Move;

/** Sprite "sPad1" */
sGraphic sPad1;
/** Límites rectangulares de "sPad1" */
oMove oPad1Move;

/** Sprite "sPad2" */
sGraphic sPad2;
/** Límites rectangulares de "sPad2" */
oMove oPad2Move;

/** Sprite "sLogo" */
sGraphic sLogo;
/** Límites rectangulares de "sLogo" */
oMove oLogo;
/** Permite saltos verticales de "sLogo" */
sJumpV oLogoJumpV;

#endif