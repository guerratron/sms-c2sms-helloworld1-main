#ifndef __STATES_H__
#define __STATES_H__

/// FUNCIONES EXTRAÍDAS DEL MARAVILLOSO BLOG DE "AVELINO HERRERA" :
/// https://avelinoherrera.com/

//#include <sdcc-lib.h>
#include <stdint.h>
#include <newTypes.h>
#include <defines.h>
#include "stage_intro.h"
#if _TUTO2_PLAY_1
    #include "stage_play.h"
#endif
#if _TUTO2_GAMEOVER_1
    #include "stage_gameover.h"
#endif

//extern game_state_e game_state;
void load_intro(uint8_t index);
game_state_e init_intro(void);
game_state_e update_fast_intro(uint16_t cont, uint32_t delta);
game_state_e update_intro(uint32_t delta, uint8_t master);
game_state_e draw_intro(uint32_t delta, uint8_t master);

#if _TUTO2_PLAY_1
    void load_play(uint8_t index);
    game_state_e init_play(void);
    game_state_e update_fast_play(uint16_t cont, uint32_t delta);
    game_state_e update_play(uint32_t delta, uint8_t master);
    game_state_e draw_play(uint32_t delta, uint8_t master);
#endif

#if _TUTO2_GAMEOVER_1
    void load_gameover(uint8_t index);
    game_state_e init_gameover(void);
    game_state_e update_fast_gameover(uint16_t cont, uint32_t delta);
    game_state_e update_gameover(uint32_t delta, uint8_t master);
    game_state_e draw_gameover(uint32_t delta, uint8_t master);
#endif

/** PRIMERA FUNCIÓN A LLAMAR PARA CARGAR LOS RECURSOS.  
 * Rellena el array de las funciones de estado de las distintas pantallas "stage" cargadas en memoria */
uint8_t loadStatesFunctions(void);
uint8_t loadStatesFunctions(void){
    // memset(sFs, NULL, _STATES_FUNCTIONS_MAX);
    uint8_t index = 0;
    load_intro(index++);
    #if _TUTO2_PLAY_1
        load_play(index++);
    #endif
    #if _TUTO2_GAMEOVER_1
        load_gameover(index++);
    #endif
    return index;
}

#endif // __STATES_H__